function openAddForm() {
  document.getElementById("addForm").style.display = "block";
  
}

function closeAddForm() {
 	document.getElementById("addForm").style.display = "none";
}

function openUpdateForm() {
  document.getElementById("updateForm").style.display = "block";
  
}

function closeUpdateForm() {
 	document.getElementById("updateForm").style.display = "none";
}

function openDeleteForm() {
  document.getElementById("deleteForm").style.display = "block";
  
}

function closeDeleteForm() {
 	document.getElementById("deleteForm").style.display = "none";
}